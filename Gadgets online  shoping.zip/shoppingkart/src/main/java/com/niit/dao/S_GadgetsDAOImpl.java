package com.niit.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.C_Gadgets;
import com.niit.model.S_Gadgets;
@EnableTransactionManagement
//connects to DB by taking attributes from POJO class
@Repository("supplierDAO")
public class S_GadgetsDAOImpl implements S_GadgetsDAO
{  //IT WILL CREATE AN OBJECT WITHOUT HELP OF NEW OPERATOER
	@Autowired
	private SessionFactory sessionfactory;
	
	public S_GadgetsDAOImpl(SessionFactory sessionfactory)
	{
		this.sessionfactory=sessionfactory;
	}
	//used to transaction from model to dao class
	@Transactional
	public void addGadgetsSupplier(S_Gadgets supplier)
	{
		sessionfactory.getCurrentSession().saveOrUpdate(supplier);
	}
	
	@Transactional
	public void deleteGadgets(String id)
	{
		S_Gadgets supplier =new S_Gadgets();
		supplier.setId(id);
		sessionfactory.getCurrentSession().delete(supplier);
		
	}
	@Transactional
	public S_Gadgets getGadgetsSupplier(String id)
	{
		String hql= "from S_Gadgets where id = " +"'" + id +"'";
		Query query = sessionfactory.getCurrentSession().createQuery(hql);
		List<S_Gadgets> listSupplier= (List<S_Gadgets>)query.list();
		if (listSupplier != null && !listSupplier.isEmpty())
		{
			return listSupplier.get(0);
		}
		return  null;
	}
	
	@Transactional
	public S_Gadgets getGadgetsName(String name)
	{
		String hql= "from S_Gadgets where name = " +"'" + name +"'";
		Query query = sessionfactory.getCurrentSession().createQuery(hql);
		List<S_Gadgets> listSupplier= (List<S_Gadgets>)query.list();
		if (listSupplier != null && !listSupplier.isEmpty())
		{
			return listSupplier.get(0);
		}
		return  null;
	}
	@Transactional
	public List<S_Gadgets> listGadgets()
	{
		List<S_Gadgets> listSupplier = (List<S_Gadgets>)sessionfactory.getCurrentSession().createCriteria(S_Gadgets.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
	     return listSupplier;
	}
}
