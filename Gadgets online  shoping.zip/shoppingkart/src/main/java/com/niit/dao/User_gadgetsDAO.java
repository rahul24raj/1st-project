package com.niit.dao;

import com.niit.model.User;

public interface User_gadgetsDAO 
{
	public void addUser(User user);
}
