package com.niit.dao;




import java.util.List;

import com.niit.model.S_Gadgets;



public interface S_GadgetsDAO 
{
	public void addGadgetsSupplier(S_Gadgets supplier);
	public S_Gadgets getGadgetsSupplier(String id);
	public void deleteGadgets(String id);
	public List<S_Gadgets> listGadgets();
	public S_Gadgets getGadgetsName(String name);
}
