package com.niit.dao;


import java.util.List;


import com.niit.model.P_Gadgets;

public interface P_GadgetsDAO
{
	public void addGadgets(P_Gadgets Product);
	public P_Gadgets getGadgets(String id);
	public void deleteGadgets(String id);
	public List<P_Gadgets> listGadgets();
	public P_Gadgets getGadgetsName(String name);
}
