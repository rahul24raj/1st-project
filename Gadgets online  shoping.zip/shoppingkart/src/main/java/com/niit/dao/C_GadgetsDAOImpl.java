package com.niit.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.C_Gadgets;


@EnableTransactionManagement
@SuppressWarnings("deprecation")
//connects to DB by taking attributes from POJO class
@Repository("categoryDAO")
public class C_GadgetsDAOImpl implements C_GadgetsDAO
{  //IT WILL CREATE AN OBJECT WITHOUT HELP OF NEW OPERATOER
	@Autowired
	private SessionFactory sessionfactory;
	
	public C_GadgetsDAOImpl(SessionFactory sessionfactory)
	{
		this.sessionfactory=sessionfactory;
	}
	//used to transaction from model to dao class
	@Transactional
	public void addGadgetsCategory(C_Gadgets category)
	{
		sessionfactory.getCurrentSession().saveOrUpdate(category);
	}
	
	@Transactional
	public void deleteGadgetsCategory(String id)
	{
		C_Gadgets category =new C_Gadgets();
		category.setId(id);
		sessionfactory.getCurrentSession().delete(category);
		
	}
	@Transactional
	public C_Gadgets getGadgetsCategory(String id)
	{
		String hql= "from C_Gadgets where id = " +"'" + id +"'";
		Query query = sessionfactory.getCurrentSession().createQuery(hql);
		List<C_Gadgets> listCategory= (List<C_Gadgets>)query.list();
		if (listCategory != null && !listCategory.isEmpty())
		{
			return listCategory.get(0);
		}
		return  null;
	}
	
	@Transactional
	public C_Gadgets getGadgetsName(String name)
	{
		String hql= "from C_Gadgets where name = " +"'" + name +"'";
		Query query = sessionfactory.getCurrentSession().createQuery(hql);
		List<C_Gadgets> listCategory= (List<C_Gadgets>)query.list();
		if (listCategory != null && !listCategory.isEmpty())
		{
			return listCategory.get(0);
		}
		return  null;
	}
	@Transactional
	public List<C_Gadgets> listGadgets()
	{
		List<C_Gadgets> listCategory = (List<C_Gadgets>)sessionfactory.getCurrentSession().createCriteria(C_Gadgets.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
	     return listCategory;
	}
}