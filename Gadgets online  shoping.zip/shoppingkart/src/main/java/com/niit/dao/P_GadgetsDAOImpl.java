package com.niit.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.C_Gadgets;
import com.niit.model.P_Gadgets;

//connects the database by taking from pojo class 
@EnableTransactionManagement
@Repository("productDAO")
public class P_GadgetsDAOImpl implements P_GadgetsDAO
{	
	@Autowired
	private SessionFactory sessionFactory; 
	
	public P_GadgetsDAOImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}
	
	
	@Transactional
	public void addGadgets(P_Gadgets product)
	{
		sessionFactory.getCurrentSession().saveOrUpdate(product);
	}
	
	@Transactional
	public void deleteGadgets(String id)
	{
		P_Gadgets product =new P_Gadgets();
		product.setId(id);
		sessionFactory.getCurrentSession().delete(product);
		
	}
	@Transactional
	public P_Gadgets getGadgets(String id)
	{
		String hql= "from P_Gadgets where id = " +"'" + id +"'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		List<P_Gadgets> listProduct= (List<P_Gadgets>)query.list();
		if (listProduct != null && !listProduct.isEmpty())
		{
			return listProduct.get(0);
		}
		return  null;
	}
	
	@Transactional
	public P_Gadgets getGadgetsName(String name)
	{
		String hql= "from P_Gadgets where name = " +"'" + name +"'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		List<P_Gadgets> listProduct= (List<P_Gadgets>)query.list();
		if (listProduct != null && !listProduct.isEmpty())
		{
			return listProduct.get(0);
		}
		return  null;
	}
	@Transactional
	public List<P_Gadgets> listGadgets()
	{
		List<P_Gadgets> listProduct = (List<P_Gadgets>)sessionFactory.getCurrentSession().createCriteria(P_Gadgets.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
	     return listProduct;
	}
}