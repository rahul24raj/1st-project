package com.niit.dao;

import java.util.List;

import com.niit.model.C_Gadgets;


public interface C_GadgetsDAO 
{
	public void addGadgetsCategory(C_Gadgets category);
	public C_Gadgets getGadgetsCategory(String id);
	public void deleteGadgetsCategory(String id);
	public List<C_Gadgets> listGadgets();
	public C_Gadgets getGadgetsName(String name);
}
