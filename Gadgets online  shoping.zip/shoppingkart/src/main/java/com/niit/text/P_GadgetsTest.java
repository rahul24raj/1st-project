package com.niit.text;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.niit.dao.P_GadgetsDAO;
import com.niit.model.P_Gadgets;

//testing for product//

public class P_GadgetsTest {

	public static void main(String[] args) 
	{
	
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		P_GadgetsDAO productDAO=(P_GadgetsDAO) context.getBean("productDAO");
		System.out.println("success");
		P_Gadgets product=(P_Gadgets) context.getBean("product");
		
		product.setId("14");
		product.setName("car");
		product.setPrice(400000);
		product.setDescription("datsun");
		
         productDAO.addGadgets(product);
		
	}

}
