package com.niit.text;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.User_gadgetsDAO;
import com.niit.model.User;

public class User_gadgetsTest 
{

	public static void main(String[] args) 
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		User_gadgetsDAO userDAO=(User_gadgetsDAO) context.getBean("userDAO");
		System.out.println("success");
		User user=(User) context.getBean("user");
		
		user.setName("ARUN");
		user.setPassword("arun01");
		user.setPhone("8451225");
		user.setEmail("arun@gmail.com");
		user.setAddress("MVM");
		
		userDAO.addUser(user);
		
		
		
	}

}