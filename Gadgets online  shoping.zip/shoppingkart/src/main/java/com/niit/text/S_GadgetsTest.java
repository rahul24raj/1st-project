package com.niit.text;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.niit.dao.S_GadgetsDAO;

import com.niit.model.S_Gadgets;

//testing for supplier in database//

public class S_GadgetsTest {

	public static void main(String[] args) 
	{
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		S_GadgetsDAO supplierDAO=(S_GadgetsDAO) context.getBean("supplierDAO");
		System.out.println("success");
		S_Gadgets supplier=(S_Gadgets) context.getBean("supplier");
		
		supplier.setId("22");
		supplier.setName("bineesh");
		supplier.setAddress("mvm");
		supplier.setPhone("7885");
		
		
		supplierDAO.addGadgetsSupplier(supplier);
		
	}
		

}
