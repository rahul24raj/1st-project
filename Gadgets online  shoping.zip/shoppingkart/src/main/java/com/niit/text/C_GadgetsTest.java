package com.niit.text;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.C_GadgetsDAO;
import com.niit.model.C_Gadgets;

//testing for category//

public class C_GadgetsTest
{
	public static void main(String[] args) 
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		C_GadgetsDAO categoryDAO=(C_GadgetsDAO) context.getBean("categoryDAO");
		System.out.println("success");
		C_Gadgets category=(C_Gadgets) context.getBean("category");
		
		category.setId("arun01");
		category.setName("ARUN");
		category.setDescription("8451225");
		
		categoryDAO.addGadgetsCategory(category);
		
		
		
	}
}